library(testthat)
test_check("mppR")