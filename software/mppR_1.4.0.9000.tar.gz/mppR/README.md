# mppR
R package for multi-parent populations QTL analysis

Start collaborative development of mppR on GitHUB (14/09/2015)
